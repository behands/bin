from __future__ import absolute_import, division, print_function, unicode_literals

import tensorflow_datasets as tfds
import tensorflow as tf
import os
from tqdm import tqdm
import time
import math
import collections

Embed_Dim = 512
units = 1024
BATCH_SIZE = 128
checkpoint_path = 'checkpoints/fr2pt'

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

def get_max_length(lines):
    sentence_list = []

    for index in range(len(lines)):
        temp = lines[index].split(' ')
        sentence_list.append(temp)

    max_length = len(max(sentence_list, key=len))

    return max_length

def get_sentence_length(sentence):
    return len(sentence.split(' '))

def read():
    train_source_path = 'data/fr_to_pt/fr.train'
    train_target_path = 'data/fr_to_pt/pt.train'

    with open(train_source_path, encoding='utf-8') as source_file:
        source_lines = source_file.readlines()
    with open(train_target_path, encoding='utf-8') as target_file:
        target_lines = target_file.readlines()

    source = []
    target = []
    for index in range(len(source_lines)):
        source.append('<bos> ' + source_lines[index][:-1] + ' <eos>')
        target.append('<bos> ' + target_lines[index][:-1] + ' <eos>')

    source_max_length = get_max_length(source)
    target_max_length = get_max_length(target)
    if source_max_length >= target_max_length:
        max_length = source_max_length
    else:
        max_length = target_max_length

    return source, target, max_length

source_lines, target_lines, max_length = read()

MAX_LENGTH = 50

BUFFER_SIZE = len(source_lines)

def make_data_dict():
    source_dict_path = 'data/fr_to_pt/fr.dic'
    target_dict_path = 'data/fr_to_pt/pt.dic'
    source = tf.constant(source_lines)
    target = tf.constant(target_lines)

    train_examples = tf.data.Dataset.from_tensor_slices((source, target))

    if os.path.exists(source_dict_path + '.subwords'):
        tokenizer_fr = tfds.features.text.SubwordTextEncoder.load_from_file(source_dict_path)
    else:
        tokenizer_fr = tfds.features.text.SubwordTextEncoder.build_from_corpus(
            (fr.numpy() for fr, pt in tqdm(train_examples)),
            target_vocab_size=2**13,
            reserved_tokens=['<bos>', '<eos>'])
        tokenizer_fr.save_to_file(source_dict_path)

    if os.path.exists(target_dict_path + '.subwords'):
        tokenizer_pt = tfds.features.text.SubwordTextEncoder.load_from_file(target_dict_path)
    else:
        tokenizer_pt = tfds.features.text.SubwordTextEncoder.build_from_corpus(
            (pt.numpy() for fr, pt in tqdm(train_examples)),
            target_vocab_size=2**13,
            reserved_tokens=['<bos>', '<eos>'])
        tokenizer_pt.save_to_file(target_dict_path)

    return tokenizer_fr, tokenizer_pt, train_examples

tokenizer_fr, tokenizer_pt, train_examples = make_data_dict()

VOCAB_FR_SIZE = tokenizer_fr.vocab_size
VOCAB_PT_SIZE = tokenizer_pt.vocab_size

def dict_test():
    sample_string = '<bos> <eos>'

    tokenized_string = tokenizer_fr.encode(sample_string)
    print('Tokenized string is {}'.format(tokenized_string))

    original_string = tokenizer_fr.decode(tokenized_string)
    print('The original string: {}'.format(original_string))

def encode(lang1, lang2):
    lang1 = tokenizer_fr.encode(lang1.numpy())
    lang2 = tokenizer_pt.encode(lang2.numpy())

    return lang1, lang2

def tf_encode(source, target):
    result_source, result_target = tf.py_function(encode, [source, target], [tf.int64, tf.int64])

    result_source.set_shape([None])
    result_target.set_shape([None])

    return result_source, result_target

def filter_max_length(x, y, max_length=MAX_LENGTH):
    return tf.logical_and(tf.size(x) <= max_length,
                        tf.size(y) <= max_length)

def make_train_datasets():
    train_dataset = train_examples.map(tf_encode)
    train_dataset = train_dataset.filter(filter_max_length)
    train_dataset = train_dataset.cache()
    train_dataset = train_dataset.shuffle(BUFFER_SIZE).padded_batch(BATCH_SIZE, padded_shapes=([MAX_LENGTH], [MAX_LENGTH]), drop_remainder=True)
    train_dataset = train_dataset.prefetch(tf.data.experimental.AUTOTUNE)

    t = list(train_dataset.as_numpy_iterator())
    steps_each_epoch = len(t)

    return train_dataset, steps_each_epoch

class Encoder(tf.keras.Model):
    def __init__(self, batch_size, enc_units, embed_size, input_vocab_size):
        super(Encoder, self).__init__()

        self.embed_size = embed_size
        self.batch_size = batch_size
        self.enc_units = enc_units

        self.embedding = tf.keras.layers.Embedding(input_vocab_size, embed_size)
        self.gru = tf.keras.layers.GRU(units=self.enc_units,
                                       return_sequences=True,
                                       return_state=True,
                                       recurrent_initializer='glorot_uniform')

    def call(self, input, hidden):
        enc_input = self.embedding(input)
        enc_output, enc_state = self.gru(enc_input, initial_state=hidden)

        return enc_output, enc_state

    def begin_state(self):
        return tf.zeros((self.batch_size, self.enc_units))
encoder = Encoder(batch_size=BATCH_SIZE,
                  enc_units=units,
                  embed_size=Embed_Dim,
                  input_vocab_size=VOCAB_FR_SIZE)

class Attention(tf.keras.layers.Layer):
    def __init__(self, units):
        super(Attention, self).__init__()
        self.W1 = tf.keras.layers.Dense(units)
        self.W2 = tf.keras.layers.Dense(units)
        self.V = tf.keras.layers.Dense(1)

    def call(self, query, values):
        hidden_with_times_axis = tf.expand_dims(query, 1)

        score = self.V(tf.nn.tanh(self.W1(values) + self.W1(hidden_with_times_axis)))

        attention_weights = tf.nn.softmax(score, axis=1)

        context_vector = attention_weights * values
        context_vector = tf.reduce_sum(context_vector, axis=1)

        return context_vector, attention_weights

class Decoder(tf.keras.Model):
    def __init__(self, batch_size, dec_units, embed_size, target_vocab_size):
        super(Decoder, self).__init__()
        self.batch_size = batch_size
        self.dec_units = dec_units
        self.embed_size = embed_size
        self.embedding = tf.keras.layers.Embedding(target_vocab_size, embed_size)
        self.gru = tf.keras.layers.GRU(units=self.dec_units,
                                       return_sequences=True,
                                       return_state=True,
                                       recurrent_initializer='glorot_uniform')
        self.fully_connect = tf.keras.layers.Dense(target_vocab_size)

        self.attention = Attention(self.dec_units)

    def call(self, input, hidden, enc_output):
        input = self.embedding(input)
        context_vector, attention_weights = self.attention(hidden, enc_output)

        input = tf.concat([tf.expand_dims(context_vector, 1), input], axis=-1)

        output, state = self.gru(input)

        output = tf.reshape(output, (-1, output.shape[2]))

        dec_output = self.fully_connect(output)

        return dec_output, state, attention_weights

    def begin_state(self, enc_state):
        return enc_state
decoder = Decoder(batch_size=BATCH_SIZE,
                  dec_units=units,
                  embed_size=Embed_Dim,
                  target_vocab_size=VOCAB_PT_SIZE)

class CustomSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):
    def __init__(self, d_model, warmup_steps=4000):
        super(CustomSchedule, self).__init__()

        self.d_model = d_model
        self.d_model = tf.cast(self.d_model, tf.float32)

        self.warmup_steps = warmup_steps

    def __call__(self, step):
        arg1 = tf.math.rsqrt(step)
        arg2 = step * (self.warmup_steps ** -1.5)

        return tf.math.rsqrt(self.d_model) * tf.math.minimum(arg1, arg2)

optimizer = tf.keras.optimizers.Adam()
loss_object = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True,
                                                            reduction='none')
def loss_function(real, pred):
    mask = tf.math.logical_not(tf.math.equal(real, 0))
    loss_ = loss_object(real, pred)

    mask = tf.cast(mask, dtype=loss_.dtype)
    loss_ *= mask

    return tf.reduce_mean(loss_)

ckpt = tf.train.Checkpoint(optimizer=optimizer,
                           encoder=encoder,
                           decoder=decoder)

ckpt_manager = tf.train.CheckpointManager(ckpt, checkpoint_path, max_to_keep=5)

if ckpt_manager.latest_checkpoint:
    ckpt.restore(ckpt_manager.latest_checkpoint)
    print('Latest checkpoint restored')

def train_step(input, target):
    loss = 0

    enc_hidden = encoder.begin_state()

    with tf.GradientTape() as tape:
        enc_output, enc_hidden = encoder(input, enc_hidden)

        dec_hidden = decoder.begin_state(enc_hidden)
        dec_input = tf.constant([tokenizer_pt.encode('<bos>')] * BATCH_SIZE)

        for index in range(1, target.shape[1]):
            predictions, dec_hidden, _ = decoder(dec_input,
                                                 dec_hidden,
                                                 enc_output)
            loss += loss_function(target[:, index], predictions)
            dec_input = tf.expand_dims(target[:, index], 1)

    batch_loss = (loss / int(target.shape[1]))
    trainable_variables = encoder.trainable_variables + decoder.trainable_variables
    gradients = tape.gradient(loss, trainable_variables)
    optimizer.apply_gradients(zip(gradients, trainable_variables))

    return batch_loss

def train(epochs=10):
    EPOCHS = epochs

    train_dataset, steps_each_epoch = make_train_datasets()

    for epoch in range(EPOCHS):
        start = time.time()

        total_loss = 0

        for (batch, (input, target)) in enumerate(train_dataset):
            batch_loss = train_step(input, target)
            total_loss += batch_loss

            if batch % 100 == 0:
                print('Epoch {} Batch {} Loss {:.4f}'.format(
                    epoch + 1, batch, batch_loss.numpy()))

        ckpt_manager.save()

        total_loss = total_loss / steps_each_epoch

        print('Epoch {} Loss {:.4f}'.format(epoch + 1, total_loss))
        print('Time taken for 1 epoch {} sec\n'.format(time.time() - start))

def evaluate(sentence):
    temp = '<bos> ' + sentence[:-1] + ' <eos>'
    tokenizer_sentence = tokenizer_fr.encode(temp)
    length = len(tokenizer_sentence)
    while len(tokenizer_sentence) < MAX_LENGTH:
        tokenizer_sentence.append(0)

    enc_input = tf.constant(tokenizer_sentence)
    enc_input = tf.expand_dims(enc_input, 0)
    hidden = tf.zeros((1, units))
    result = ''
    enc_output, enc_hidden = encoder(enc_input, hidden)

    dec_hidden = decoder.begin_state(enc_hidden)
    dec_input = tf.constant([tokenizer_pt.encode('<bos>')])

    for t in range(length):
        prediction, dec_hidden, _ = decoder(dec_input,
                                            dec_hidden,
                                            enc_output)
        predicted_id = tf.argmax(prediction[0])
        token = [predicted_id.numpy().tolist()]

        result += tokenizer_pt.decode(token) + ' '

        dec_input = tf.expand_dims([predicted_id], 0)
        if tokenizer_pt.decode(token) == '<eos>':
            return result

    return result

def translate():
    test_source_path = 'data/fr_to_pt/fr.test'

    with open(test_source_path, encoding='utf-8') as source_file:
        source_read = source_file.readlines()

    predictions = []
    for t in range(len(source_read)):
        result = evaluate(source_read[t])
        print('Sentence ', t + 1)
        print('FR:', source_read[t][:-1])
        print('PT:', result+'\n')
        predictions.append(result)

    if os.path.exists('data/fr_to_pt/predicted.txt'):
        os.remove('data/fr_to_pt/predicted.txt')
    with open('data/fr_to_pt/predicted.txt', encoding='utf-8', mode='w') as pred:
        for i in range(len(predictions)):
            pred.write(predictions[i] + '\n')

def bleu(pred_sentence, label_sentence, k):
    pred_token = pred_sentence.split(' ')
    label_token = label_sentence.split(' ')
    len_pred, len_label = len(pred_token), len(label_token)
    score = math.exp(min(0, 1 - len_label / len_pred))
    for n in range(1, k + 1):
        num_matches, label_subs = 0, collections.defaultdict(int)
        for i in range(len_label - n + 1):
            label_subs[''.join(label_token[i: i + n])] += 1
        for i in range(len_pred - n + 1):
            if label_subs[''.join(pred_token[i: i + n])] > 0:
                num_matches += 1
                label_subs[''.join(pred_token[i: i + n])] -= 1
        score *= math.pow(num_matches / (len_pred - n + 1), math.pow(0.5, n))
    return score

def test_bleu():
    test_target_path = 'data/fr_to_pt/pt.test'
    test_predict_path = 'data/fr_to_pt/predicted.txt'
    with open(test_target_path, encoding='utf-8') as target_file:
        target_read = target_file.readlines()
    with open(test_predict_path, encoding='utf-8') as predict_file:
        predict_read = predict_file.readlines()

    total_score = []
    for index in range(len(predict_read)):
        candi = predict_read[index][:-1]
        refer = target_read[index][:-1]
        score = bleu(candi, refer, 2)
        total_score.append(score)

    max_score = max(total_score)
    print('{:.3f}'.format(max_score))

if __name__ == '__main__':
    # train()
    # translate()
    print('可以自行选择进行训练或是直接翻译。\n'
          '但是模型没有经过训练因此直接翻译的结果都是随机的。\n'
          'BLEU的测试，使用的预测结果，是已经训练好的模型输出的结果，并不一定就是最好的。\n'
          '此外，可以对程序进行修改，例如在运行时通过传入参数，确定超参、运行模式等等。')